namespace CollegeManagement.Models;

/// Задачи 9, 10, 18: преподаватель.
public class Teacher : Person
{
    private Teacher() { }

    public Teacher(string name, string surname, int age, string subjectName, int experience)
        : base(name, surname, age)
    {
        SubjectName = RequireText(subjectName, "Предмет");
        UpdateExperience(experience);
    }

    public string SubjectName { get; private set; } = "";

    // Задача 10: стаж меняется только через UpdateExperience()
    public int Experience { get; private set; }

    public void UpdateExperience(int years)
    {
        if (years < 0 || years > 60)
            throw new ArgumentOutOfRangeException(nameof(years), "Стаж должен быть от 0 до 60 лет.");
        if (years < Experience)
            throw new InvalidOperationException("Стаж не может уменьшаться.");
        Experience = years;
    }

    // Задача 18: отдельный метод отображения
    public string GetTeacherInfo() =>
        $"{DisplayBasicInfo()}, предмет: {SubjectName}, стаж: {Experience} лет";
}

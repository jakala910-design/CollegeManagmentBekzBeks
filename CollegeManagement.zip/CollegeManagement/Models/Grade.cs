namespace CollegeManagement.Models;

public class Grade
{
    private Grade() { }
    internal Grade(int studentId, int subjectId, int value, DateOnly date)
    {
        StudentId = studentId; SubjectId = subjectId; Value = value; Date = date;
    }

    public int Id { get; private set; }
    public int StudentId { get; private set; }
    public int SubjectId { get; private set; }
    public int Value { get; private set; }
    public DateOnly Date { get; private set; }
}

/// Задача 28: журнал оценок, список закрыт, оценки 2–5.
public class GradeBook
{
    private readonly List<Grade> _grades;

    public GradeBook(IEnumerable<Grade>? existing = null) => _grades = existing?.ToList() ?? new List<Grade>();

    public IReadOnlyList<Grade> Grades => _grades;

    public Grade AddGrade(int studentId, int subjectId, int value, DateOnly? date = null)
    {
        if (value < 2 || value > 5)
            throw new ArgumentOutOfRangeException(nameof(value), "Допустимые оценки: от 2 до 5.");
        var grade = new Grade(studentId, subjectId, value, date ?? DateOnly.FromDateTime(DateTime.Today));
        _grades.Add(grade);
        return grade;
    }

    public Grade? RemoveGrade(int gradeId)
    {
        var grade = _grades.FirstOrDefault(g => g.Id == gradeId);
        if (grade != null) _grades.Remove(grade);
        return grade;
    }

    public double? Average(int studentId, int? subjectId = null)
    {
        var list = _grades.Where(g => g.StudentId == studentId && (subjectId == null || g.SubjectId == subjectId)).ToList();
        return list.Count == 0 ? null : list.Average(g => g.Value);
    }
}

namespace CollegeManagement.Models;

/// Задачи 16, 19, 20, 23, 25: базовый класс с protected / protected internal / private protected.
public abstract class Person
{
    // protected — доступны наследникам (задача 16)
    protected string _name = "";
    protected string _surname = "";
    protected int _age;

    // private — доступно ТОЛЬКО внутри Person, наследники это поле не видят (задача 20)
    private readonly DateTime _createdAt = DateTime.Now;

    protected Person() { }                       // для EF Core

    protected Person(string name, string surname, int age)
    {
        Name = name;
        Surname = surname;
        SetAge(age);
    }

    public int Id { get; private set; }

    public string Name
    {
        get => _name;
        set => _name = RequireText(value, "Имя");
    }

    public string Surname
    {
        get => _surname;
        set => _surname = RequireText(value, "Фамилия");
    }

    public int Age
    {
        get => _age;
        private set => _age = value;
    }

    public string RegisteredOn => _createdAt.ToString("dd.MM.yyyy");

    /// Задача 4: возраст только 15–70
    public void SetAge(int age)
    {
        if (age < 15 || age > 70)
            throw new ArgumentOutOfRangeException(nameof(age), "Возраст должен быть от 15 до 70 лет.");
        _age = age;
    }

    // Задача 2: публичные методы получения информации
    public string GetName() => _name;
    public string GetSurname() => _surname;
    public int GetAge() => _age;

    public string FullName => GetFullName();

    protected static string RequireText(string? value, string field)
    {
        if (string.IsNullOrWhiteSpace(value))
            throw new ArgumentException($"Поле «{field}» не может быть пустым.");
        return value.Trim();
    }

    // Задача 19: protected-метод
    protected string DisplayBasicInfo() => $"{_surname} {_name}, {_age} лет";

    // Задача 23: protected internal — виден в этой сборке и в наследниках
    protected internal string GetFullName() => $"{_surname} {_name}";

    // Задача 25: private protected — только наследники внутри этой же сборки
    private protected string CalculateStatistics() =>
        _age < 18 ? "младше 18" : _age <= 25 ? "18–25 лет" : "старше 25";
}

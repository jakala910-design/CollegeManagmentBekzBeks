namespace CollegeManagement.Models;

/// Задачи 21–22: internal-класс настроек, изменение — только внутри сборки.
internal class CollegeSettings
{
    private CollegeSettings() { }

    public static CollegeSettings Current { get; } = new()
    {
        Title = "Колледж ЕНУ им. Л. Н. Гумилева",
        AcademicYear = "2026/2027"
    };

    public string Title { get; private set; } = "";
    public string AcademicYear { get; private set; } = "";

    internal void UpdateTitle(string title)
    {
        if (!string.IsNullOrWhiteSpace(title)) Title = title.Trim();
    }

    internal void UpdateAcademicYear(string year)
    {
        if (!string.IsNullOrWhiteSpace(year)) AcademicYear = year.Trim();
    }
}

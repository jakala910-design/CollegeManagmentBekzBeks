namespace CollegeManagement.Models;

/// Задачи 11–13: учебная группа, список студентов закрыт.
public class Group
{
    private readonly List<Student> _students = new();      // private

    private Group() { }

    public Group(string title, int course)
    {
        if (string.IsNullOrWhiteSpace(title)) throw new ArgumentException("Название группы обязательно.");
        if (course < 1 || course > 4) throw new ArgumentOutOfRangeException(nameof(course), "Курс от 1 до 4.");
        Title = title.Trim();
        Course = course;
    }

    public int Id { get; private set; }
    public string Title { get; private set; } = "";
    public int Course { get; private set; }

    // Наружу — только чтение: Add/Remove на коллекции извне невозможны (задача 13)
    public IEnumerable<Student> Students => _students.AsReadOnly();

    // Задача 12: добавить, только если студента ещё нет в группе
    public bool AddStudent(Student student)
    {
        ArgumentNullException.ThrowIfNull(student);
        if (_students.Any(s => s.StudentId == student.StudentId)) return false;
        _students.Add(student);
        student.AssignToGroup(Id, Title);
        return true;
    }

    // Задача 13
    public bool RemoveStudent(Student student)
    {
        ArgumentNullException.ThrowIfNull(student);
        var removed = _students.RemoveAll(s => s.StudentId == student.StudentId) > 0;
        if (removed) student.AssignToGroup(null, "Без группы");
        return removed;
    }
}

using System.ComponentModel.DataAnnotations.Schema;
using System.Security.Cryptography;
using System.Text;

namespace CollegeManagement.Models;

/// Задача 26: учётная запись. Логин и пароль — приватные поля, пароль хранится как хэш и не выводится.
public class UserAccount
{
    private string _login = "";
    private string _passwordHash = "";

    private UserAccount() { }

    public UserAccount(string login, string password, string role, string fullName)
    {
        if (string.IsNullOrWhiteSpace(login)) throw new ArgumentException("Логин обязателен.");
        if (string.IsNullOrWhiteSpace(password) || password.Length < 6)
            throw new ArgumentException("Пароль должен быть не короче 6 символов.");
        if (role is not ("Admin" or "Teacher" or "Student"))
            throw new ArgumentException("Роль: Admin, Teacher или Student.");
        _login = login.Trim();
        _passwordHash = Hash(password);
        Role = role;
        FullName = string.IsNullOrWhiteSpace(fullName) ? login : fullName.Trim();
    }

    public int Id { get; private set; }
    public string Role { get; private set; } = "";
    public string FullName { get; private set; } = "";
    public string UserName => _login;

    [NotMapped]
    public bool IsLoggedIn { get; private set; }

    public bool Login(string login, string password)
    {
        IsLoggedIn = login == _login && Hash(password ?? "") == _passwordHash;
        return IsLoggedIn;
    }

    public void Logout() => IsLoggedIn = false;

    private static string Hash(string password) =>
        Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes("college-salt:" + password)));

    // пароль никогда не попадает в вывод
    public override string ToString() => $"{_login} ({Role}), пароль: ********";
}

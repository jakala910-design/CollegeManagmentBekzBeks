namespace CollegeManagement.Models;

/// Задача 27: иерархия ролей. protected — общие данные, private — конфиденциальное.
public abstract class User
{
    protected string FullName { get; }
    protected string Role { get; }
    private readonly string _accessToken = Guid.NewGuid().ToString("N");   // private

    protected User(string fullName, string role)
    {
        FullName = fullName;
        Role = role;
    }

    public virtual string Describe() => $"{Role}: {FullName}";
    protected string MaskedToken() => _accessToken[..4] + "****";
}

public class AdminUser : User
{
    public AdminUser(string fullName) : base(fullName, "Администратор") { }
    public override string Describe() => $"{base.Describe()} — полный доступ, токен {MaskedToken()}";
}

public class TeacherUser : User
{
    public TeacherUser(string fullName) : base(fullName, "Преподаватель") { }
    public override string Describe() => $"{base.Describe()} — выставляет оценки и посещаемость";
}

public class StudentUser : User
{
    public StudentUser(string fullName) : base(fullName, "Студент") { }
    public override string Describe() => $"{base.Describe()} — только просмотр";
}

namespace CollegeManagement.Models;

/// Задачи 1–8, 17: публичный класс студента, наследник Person.
public class Student : Person
{
    private Student() { }                        // для EF Core

    // Задача 5: публичный конструктор
    public Student(string name, string surname, int age, string groupName)
        : base(name, surname, age)
    {
        GroupName = groupName;
        ValidateStudentData();                   // Задача 6
        StudentId = "ST-" + Guid.NewGuid().ToString("N")[..8].ToUpperInvariant();
    }

    // Задача 8: только чтение после создания
    public string StudentId { get; private set; } = "";

    public int? GroupId { get; private set; }
    public string GroupName { get; private set; } = "";

    // Задача 6: приватный метод проверки
    private void ValidateStudentData()
    {
        if (string.IsNullOrWhiteSpace(_name) || string.IsNullOrWhiteSpace(_surname))
            throw new ArgumentException("Имя и фамилия обязательны.");
        if (string.IsNullOrWhiteSpace(GroupName))
            throw new ArgumentException("Группа обязательна.");
    }

    // Задача 7 (+19, 25): информация о студенте
    public string GetStudentInfo() =>
        $"[{StudentId}] {DisplayBasicInfo()}, группа {GroupName}, категория: {CalculateStatistics()}";

    // internal — менять группу может только код внутри сборки (класс Group)
    internal void AssignToGroup(int? groupId, string groupName)
    {
        GroupId = groupId;
        GroupName = groupName;
    }
}

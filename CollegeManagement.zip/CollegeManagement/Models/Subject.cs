namespace CollegeManagement.Models;

/// Задачи 14–15: учебный предмет.
public class Subject
{
    private Subject() { }

    public Subject(string title, int hours)
    {
        if (string.IsNullOrWhiteSpace(title)) throw new ArgumentException("Название предмета обязательно.");
        if (hours <= 0) throw new ArgumentOutOfRangeException(nameof(hours), "Количество часов должно быть > 0.");
        Title = title.Trim();
        Hours = hours;
    }

    public int Id { get; private set; }
    public string Title { get; private set; } = "";
    public int Hours { get; private set; }
    public int? TeacherId { get; private set; }
    public Teacher? Teacher { get; private set; }

    // Задача 15
    public void AssignTeacher(Teacher teacher)
    {
        ArgumentNullException.ThrowIfNull(teacher);
        Teacher = teacher;
        TeacherId = teacher.Id;
    }
}

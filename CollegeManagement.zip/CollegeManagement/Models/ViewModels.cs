using CollegeManagement.Services;

namespace CollegeManagement.Models;

public class TeacherPageVm
{
    public List<Teacher> Teachers { get; set; } = new();
    public List<Subject> Subjects { get; set; } = new();
}

public class GroupDetailsVm
{
    public Group Group { get; set; } = null!;
    public List<Student> Available { get; set; } = new();
    public string Report { get; set; } = "";
}

public class GradePageVm
{
    public List<Subject> Subjects { get; set; } = new();
    public Subject? Selected { get; set; }
    public List<Student> Students { get; set; } = new();
    public GradeBook Book { get; set; } = new();
}

public class AttendancePageVm
{
    public DateOnly Date { get; set; }
    public List<Student> Students { get; set; } = new();
    public AttendanceManager Manager { get; set; } = new(Array.Empty<AttendanceRecord>());
}

public class AdminPageVm
{
    public List<UserAccount> Users { get; set; } = new();
    public List<string> RoleDescriptions { get; set; } = new();
}

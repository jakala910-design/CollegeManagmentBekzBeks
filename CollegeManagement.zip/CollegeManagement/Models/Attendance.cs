namespace CollegeManagement.Models;

public class AttendanceRecord
{
    private AttendanceRecord() { }
    internal AttendanceRecord(int studentId, DateOnly date, bool present)
    {
        StudentId = studentId; Date = date; Present = present;
    }

    public int Id { get; private set; }
    public int StudentId { get; private set; }
    public DateOnly Date { get; private set; }
    public bool Present { get; private set; }

    internal void Mark(bool present) => Present = present;
}

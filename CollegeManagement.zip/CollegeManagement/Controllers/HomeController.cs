using CollegeManagement.Data;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace CollegeManagement.Controllers;

public class HomeController : Controller
{
    private readonly CollegeDbContext _db;
    public HomeController(CollegeDbContext db) => _db = db;

    public async Task<IActionResult> Index()
    {
        ViewBag.Students = await _db.Students.CountAsync();
        ViewBag.Teachers = await _db.Teachers.CountAsync();
        ViewBag.Groups = await _db.Groups.CountAsync();
        ViewBag.Subjects = await _db.Subjects.CountAsync();
        return View();
    }
}

using CollegeManagement.Data;
using CollegeManagement.Models;
using CollegeManagement.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace CollegeManagement.Controllers;

public class AttendanceController : Controller
{
    private readonly CollegeDbContext _db;
    public AttendanceController(CollegeDbContext db) => _db = db;

    public async Task<IActionResult> Index(DateOnly? date) => View(new AttendancePageVm
    {
        Date = date ?? DateOnly.FromDateTime(DateTime.Today),
        Students = await _db.Students.OrderBy(s => s.GroupName).ThenBy(s => s.Surname).ToListAsync(),
        Manager = new AttendanceManager(await _db.Attendance.ToListAsync())
    });

    [HttpPost, ValidateAntiForgeryToken, Authorize(Roles = "Admin,Teacher")]
    public async Task<IActionResult> Mark(int studentId, DateOnly date, bool present)
    {
        var manager = new AttendanceManager(await _db.Attendance.Where(a => a.StudentId == studentId).ToListAsync());
        if (manager.Find(studentId, date) == null)
            _db.Attendance.Add(manager.AddRecord(studentId, date, present));
        else
            manager.ChangeRecord(studentId, date, present);
        await _db.SaveChangesAsync();
        return RedirectToAction(nameof(Index), new { date = date.ToString("yyyy-MM-dd") });
    }
}

using System.Security.Claims;
using CollegeManagement.Data;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace CollegeManagement.Controllers;

[AllowAnonymous]
public class AccountController : Controller
{
    private readonly CollegeDbContext _db;
    public AccountController(CollegeDbContext db) => _db = db;

    [HttpGet]
    public IActionResult Login() => View();

    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> Login(string login, string password)
    {
        var acc = await _db.Users.FirstOrDefaultAsync(u => EF.Property<string>(u, "_login") == login);
        if (acc is null || !acc.Login(login, password))
        {
            ViewBag.Error = "Неверный логин или пароль.";
            return View();
        }

        var claims = new List<Claim>
        {
            new(ClaimTypes.Name, acc.FullName),
            new(ClaimTypes.Role, acc.Role),
            new("login", acc.UserName)
        };
        var principal = new ClaimsPrincipal(new ClaimsIdentity(claims, CookieAuthenticationDefaults.AuthenticationScheme));
        await HttpContext.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme, principal);
        return RedirectToAction("Index", "Home");
    }

    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> Logout()
    {
        await HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
        return RedirectToAction(nameof(Login));
    }

    public IActionResult Denied() => View();
}

using CollegeManagement.Data;
using CollegeManagement.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace CollegeManagement.Controllers;

[Authorize(Roles = "Admin")]
public class AdminController : Controller
{
    private readonly CollegeDbContext _db;
    public AdminController(CollegeDbContext db) => _db = db;

    public async Task<IActionResult> Index() => View(new AdminPageVm
    {
        Users = await _db.Users.OrderBy(u => u.Id).ToListAsync(),
        RoleDescriptions = new List<string>
        {
            new AdminUser("Иванов И.").Describe(),
            new TeacherUser("Петрова С.").Describe(),
            new StudentUser("Нурланов А.").Describe()
        }
    });

    [HttpPost, ValidateAntiForgeryToken]
    public IActionResult UpdateSettings(string title, string year)
    {
        CollegeSettings.Current.UpdateTitle(title);          // internal (задача 22)
        CollegeSettings.Current.UpdateAcademicYear(year);
        TempData["Ok"] = "Настройки сохранены.";
        return RedirectToAction(nameof(Index));
    }

    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> CreateUser(string login, string password, string role, string fullName)
    {
        try
        {
            _db.Users.Add(new UserAccount(login, password, role, fullName));
            await _db.SaveChangesAsync();
            TempData["Ok"] = "Пользователь создан.";
        }
        catch (ArgumentException ex) { TempData["Error"] = ex.Message; }
        catch (DbUpdateException) { TempData["Error"] = "Такой логин уже существует."; }
        return RedirectToAction(nameof(Index));
    }

    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> DeleteUser(int id)
    {
        var user = await _db.Users.FindAsync(id);
        if (user == null) return RedirectToAction(nameof(Index));
        if (user.UserName == User.FindFirst("login")?.Value)
        {
            TempData["Error"] = "Нельзя удалить самого себя.";
            return RedirectToAction(nameof(Index));
        }
        _db.Users.Remove(user);
        await _db.SaveChangesAsync();
        TempData["Ok"] = "Пользователь удалён.";
        return RedirectToAction(nameof(Index));
    }
}

using CollegeManagement.Data;
using CollegeManagement.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace CollegeManagement.Controllers;

public class StudentController : Controller
{
    private readonly StudentService _svc;
    private readonly CollegeDbContext _db;
    public StudentController(StudentService svc, CollegeDbContext db) { _svc = svc; _db = db; }

    public async Task<IActionResult> Index()
    {
        ViewBag.Groups = await _db.Groups.OrderBy(g => g.Title).ToListAsync();
        return View(await _svc.GetAllAsync());
    }

    [HttpPost, ValidateAntiForgeryToken, Authorize(Roles = "Admin,Teacher")]
    public async Task<IActionResult> Create(string name, string surname, int age, int groupId)
    {
        try
        {
            await _svc.AddAsync(name, surname, age, groupId);
            TempData["Ok"] = "Студент добавлен.";
        }
        catch (Exception ex) when (ex is ArgumentException or InvalidOperationException)
        {
            TempData["Error"] = ex.Message;
        }
        return RedirectToAction(nameof(Index));
    }

    [HttpPost, ValidateAntiForgeryToken, Authorize(Roles = "Admin,Teacher")]
    public async Task<IActionResult> Delete(int id)
    {
        await _svc.DeleteAsync(id);
        TempData["Ok"] = "Студент удалён.";
        return RedirectToAction(nameof(Index));
    }
}

using CollegeManagement.Data;
using CollegeManagement.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace CollegeManagement.Controllers;

public class TeacherController : Controller
{
    private readonly CollegeDbContext _db;
    public TeacherController(CollegeDbContext db) => _db = db;

    public async Task<IActionResult> Index() => View(new TeacherPageVm
    {
        Teachers = await _db.Teachers.OrderBy(t => t.Surname).ToListAsync(),
        Subjects = await _db.Subjects.Include(s => s.Teacher).OrderBy(s => s.Title).ToListAsync()
    });

    [HttpPost, ValidateAntiForgeryToken, Authorize(Roles = "Admin")]
    public async Task<IActionResult> Create(string name, string surname, int age, string subject, int experience)
    {
        try
        {
            _db.Teachers.Add(new Teacher(name, surname, age, subject, experience));
            await _db.SaveChangesAsync();
            TempData["Ok"] = "Преподаватель добавлен.";
        }
        catch (Exception ex) when (ex is ArgumentException or InvalidOperationException)
        {
            TempData["Error"] = ex.Message;
        }
        return RedirectToAction(nameof(Index));
    }

    [HttpPost, ValidateAntiForgeryToken, Authorize(Roles = "Admin")]
    public async Task<IActionResult> UpdateExperience(int id, int years)
    {
        var teacher = await _db.Teachers.FindAsync(id);
        if (teacher == null) return NotFound();
        try
        {
            teacher.UpdateExperience(years);
            await _db.SaveChangesAsync();
            TempData["Ok"] = "Стаж обновлён.";
        }
        catch (Exception ex) when (ex is ArgumentException or InvalidOperationException)
        {
            TempData["Error"] = ex.Message;
        }
        return RedirectToAction(nameof(Index));
    }

    [HttpPost, ValidateAntiForgeryToken, Authorize(Roles = "Admin")]
    public async Task<IActionResult> AssignTeacher(int subjectId, int teacherId)
    {
        var subject = await _db.Subjects.FindAsync(subjectId);
        var teacher = await _db.Teachers.FindAsync(teacherId);
        if (subject == null) return NotFound();
        try
        {
            subject.AssignTeacher(teacher!);       // null -> ArgumentNullException (задача 15)
            await _db.SaveChangesAsync();
            TempData["Ok"] = "Преподаватель назначен.";
        }
        catch (ArgumentNullException)
        {
            TempData["Error"] = "Преподаватель не выбран.";
        }
        return RedirectToAction(nameof(Index));
    }
}

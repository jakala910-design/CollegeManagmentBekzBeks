using CollegeManagement.Data;
using CollegeManagement.Models;
using CollegeManagement.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace CollegeManagement.Controllers;

public class GroupController : Controller
{
    private readonly CollegeDbContext _db;
    private readonly DetailedReportManager _reports;
    public GroupController(CollegeDbContext db, DetailedReportManager reports) { _db = db; _reports = reports; }

    public async Task<IActionResult> Index() =>
        View(await _db.Groups.Include(g => g.Students).OrderBy(g => g.Title).ToListAsync());

    [HttpPost, ValidateAntiForgeryToken, Authorize(Roles = "Admin")]
    public async Task<IActionResult> Create(string title, int course)
    {
        try
        {
            _db.Groups.Add(new Group(title, course));
            await _db.SaveChangesAsync();
            TempData["Ok"] = "Группа создана.";
        }
        catch (ArgumentException ex) { TempData["Error"] = ex.Message; }
        return RedirectToAction(nameof(Index));
    }

    public async Task<IActionResult> Details(int id)
    {
        var group = await _db.Groups.Include(g => g.Students).FirstOrDefaultAsync(g => g.Id == id);
        if (group == null) return NotFound();

        var ids = group.Students.Select(s => s.Id).ToList();
        var grades = await _db.Grades.Where(g => ids.Contains(g.StudentId)).ToListAsync();
        var att = await _db.Attendance.Where(a => ids.Contains(a.StudentId)).ToListAsync();

        return View(new GroupDetailsVm
        {
            Group = group,
            Available = await _db.Students.Where(s => s.GroupId != id || s.GroupId == null).OrderBy(s => s.Surname).ToListAsync(),
            Report = _reports.Build(group, new GradeBook(grades), new AttendanceManager(att))
        });
    }

    [HttpPost, ValidateAntiForgeryToken, Authorize(Roles = "Admin,Teacher")]
    public async Task<IActionResult> AddStudent(int groupId, int studentId)
    {
        var group = await _db.Groups.Include(g => g.Students).FirstOrDefaultAsync(g => g.Id == groupId);
        var student = await _db.Students.FindAsync(studentId);
        if (group == null || student == null) return NotFound();

        if (student.GroupId != null)
        {
            var old = await _db.Groups.Include(g => g.Students).FirstOrDefaultAsync(g => g.Id == student.GroupId);
            old?.RemoveStudent(student);
        }
        var added = group.AddStudent(student);
        TempData[added ? "Ok" : "Error"] = added ? "Студент добавлен в группу." : "Студент уже состоит в этой группе.";
        await _db.SaveChangesAsync();
        return RedirectToAction(nameof(Details), new { id = groupId });
    }

    [HttpPost, ValidateAntiForgeryToken, Authorize(Roles = "Admin,Teacher")]
    public async Task<IActionResult> RemoveStudent(int groupId, int studentId)
    {
        var group = await _db.Groups.Include(g => g.Students).FirstOrDefaultAsync(g => g.Id == groupId);
        var student = group?.Students.FirstOrDefault(s => s.Id == studentId);
        if (group == null || student == null) return NotFound();
        group.RemoveStudent(student);
        await _db.SaveChangesAsync();
        TempData["Ok"] = "Студент исключён из группы.";
        return RedirectToAction(nameof(Details), new { id = groupId });
    }
}

using CollegeManagement.Data;
using CollegeManagement.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace CollegeManagement.Controllers;

public class GradeController : Controller
{
    private readonly CollegeDbContext _db;
    public GradeController(CollegeDbContext db) => _db = db;

    public async Task<IActionResult> Index(int? subjectId)
    {
        var subjects = await _db.Subjects.OrderBy(s => s.Title).ToListAsync();
        var selected = subjects.FirstOrDefault(s => s.Id == subjectId) ?? subjects.FirstOrDefault();
        var vm = new GradePageVm
        {
            Subjects = subjects,
            Selected = selected,
            Students = await _db.Students.OrderBy(s => s.GroupName).ThenBy(s => s.Surname).ToListAsync()
        };
        if (selected != null)
            vm.Book = new GradeBook(await _db.Grades.Where(g => g.SubjectId == selected.Id).ToListAsync());
        return View(vm);
    }

    [HttpPost, ValidateAntiForgeryToken, Authorize(Roles = "Admin,Teacher")]
    public async Task<IActionResult> Add(int studentId, int subjectId, int value)
    {
        try
        {
            _db.Grades.Add(new GradeBook().AddGrade(studentId, subjectId, value));
            await _db.SaveChangesAsync();
        }
        catch (ArgumentOutOfRangeException ex) { TempData["Error"] = ex.Message; }
        return RedirectToAction(nameof(Index), new { subjectId });
    }

    [HttpPost, ValidateAntiForgeryToken, Authorize(Roles = "Admin,Teacher")]
    public async Task<IActionResult> Remove(int id, int subjectId)
    {
        var book = new GradeBook(await _db.Grades.Where(g => g.SubjectId == subjectId).ToListAsync());
        var removed = book.RemoveGrade(id);
        if (removed != null)
        {
            _db.Grades.Remove(removed);
            await _db.SaveChangesAsync();
        }
        return RedirectToAction(nameof(Index), new { subjectId });
    }
}

using System.Text;
using CollegeManagement.Models;

namespace CollegeManagement.Services;

/// Задача 24: protected internal GenerateReport().
public class ReportManager
{
    protected internal string GenerateReport(Group group, GradeBook book, AttendanceManager attendance)
    {
        var sb = new StringBuilder();
        sb.AppendLine($"Отчёт по группе {group.Title} (курс {group.Course})");
        sb.AppendLine($"Студентов: {group.Students.Count()}");
        foreach (var s in group.Students.OrderBy(s => s.Surname))
        {
            var avg = book.Average(s.Id);
            var st = attendance.GetStatistics(s.Id);
            sb.AppendLine($" • {s.FullName}: средний балл {(avg.HasValue ? avg.Value.ToString("0.00") : "—")}, посещаемость {st.Percent:0}%");
        }
        return sb.ToString();
    }
}

/// Наследник — вызывает protected-метод базового класса.
public class DetailedReportManager : ReportManager
{
    public string Build(Group group, GradeBook book, AttendanceManager attendance) =>
        GenerateReport(group, book, attendance) + $"Сформировано: {DateTime.Now:dd.MM.yyyy HH:mm}";
}

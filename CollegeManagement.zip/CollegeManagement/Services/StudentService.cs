using CollegeManagement.Data;
using CollegeManagement.Models;
using Microsoft.EntityFrameworkCore;

namespace CollegeManagement.Services;

public class StudentService
{
    private readonly CollegeDbContext _db;
    public StudentService(CollegeDbContext db) => _db = db;

    public Task<List<Student>> GetAllAsync() =>
        _db.Students.OrderBy(s => s.GroupName).ThenBy(s => s.Surname).ToListAsync();

    public async Task AddAsync(string name, string surname, int age, int groupId)
    {
        var group = await _db.Groups.Include(g => g.Students).FirstOrDefaultAsync(g => g.Id == groupId)
                    ?? throw new InvalidOperationException("Группа не найдена.");
        var student = new Student(name, surname, age, group.Title);
        if (!group.AddStudent(student)) throw new InvalidOperationException("Студент уже в группе.");
        _db.Students.Add(student);
        await _db.SaveChangesAsync();
    }

    public async Task DeleteAsync(int id)
    {
        var student = await _db.Students.FindAsync(id);
        if (student == null) return;
        _db.Grades.RemoveRange(_db.Grades.Where(g => g.StudentId == id));
        _db.Attendance.RemoveRange(_db.Attendance.Where(a => a.StudentId == id));
        _db.Students.Remove(student);
        await _db.SaveChangesAsync();
    }
}

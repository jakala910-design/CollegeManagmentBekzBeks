using CollegeManagement.Models;

namespace CollegeManagement.Services;

/// Задача 29: внутренние данные о посещаемости приватны.
public class AttendanceManager
{
    private readonly List<AttendanceRecord> _records;

    public AttendanceManager(IEnumerable<AttendanceRecord> existing) => _records = existing.ToList();

    public AttendanceRecord? Find(int studentId, DateOnly date) =>
        _records.FirstOrDefault(r => r.StudentId == studentId && r.Date == date);

    public AttendanceRecord AddRecord(int studentId, DateOnly date, bool present)
    {
        if (Find(studentId, date) != null)
            throw new InvalidOperationException("Отметка на эту дату уже существует.");
        var record = new AttendanceRecord(studentId, date, present);
        _records.Add(record);
        return record;
    }

    public AttendanceRecord ChangeRecord(int studentId, DateOnly date, bool present)
    {
        var record = Find(studentId, date) ?? throw new InvalidOperationException("Отметка не найдена.");
        record.Mark(present);
        return record;
    }

    public (int Total, int Present, double Percent) GetStatistics(int studentId)
    {
        var list = _records.Where(r => r.StudentId == studentId).ToList();
        int present = list.Count(r => r.Present);
        return (list.Count, present, list.Count == 0 ? 0 : present * 100.0 / list.Count);
    }
}

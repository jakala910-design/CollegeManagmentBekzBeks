# CollegeManagement — ASP.NET Core MVC (.NET 8) + SQLite

## Запуск
1. Установить .NET 8 SDK.
2. В папке проекта: `dotnet run`
3. Открыть адрес из консоли (обычно http://localhost:5000 или 5xxx).
   База `college.db` создаётся и заполняется тестовыми данными автоматически.

Тестовые входы: `admin / admin123`, `teacher / teacher123`, `student / student123`.
Права: Admin — всё; Teacher — оценки, посещаемость, состав групп; Student — только просмотр.

## Где реализованы задачи
| Задачи | Файл |
|---|---|
| 1–8, 17, 19 | Models/Student.cs, Models/Person.cs |
| 9–10, 18 | Models/Teacher.cs |
| 11–13 | Models/Group.cs |
| 14–15 | Models/Subject.cs |
| 16, 19, 20, 23, 25 | Models/Person.cs (protected / private / protected internal / private protected) |
| 21–22 | Models/CollegeSettings.cs (internal) |
| 24 | Services/ReportManager.cs (protected internal GenerateReport) |
| 26 | Models/UserAccount.cs |
| 27 | Models/User.cs (User, AdminUser, TeacherUser, StudentUser) |
| 28 | Models/Grade.cs (GradeBook, оценки 2–5) |
| 29 | Services/AttendanceManager.cs |
| 30 | Controllers/*, Views/*, Data/CollegeDbContext.cs, Program.cs |

using CollegeManagement.Models;

namespace CollegeManagement.Data;

public static class SeedData
{
    public static void Initialize(CollegeDbContext db)
    {
        if (db.Users.Any()) return;

        db.Users.AddRange(
            new UserAccount("admin", "admin123", "Admin", "Администратор системы"),
            new UserAccount("teacher", "teacher123", "Teacher", "Преподаватель"),
            new UserAccount("student", "student123", "Student", "Студент"));

        var g1 = new Group("2 ПО 525", 2);
        var g2 = new Group("1 ИС 124", 1);
        db.Groups.AddRange(g1, g2);
        db.SaveChanges();                        // чтобы у групп появились Id

        var students = new List<(Student s, Group g)>
        {
            (new Student("Айдар", "Нурланов", 19, g1.Title), g1),
            (new Student("Алия", "Серикова", 18, g1.Title), g1),
            (new Student("Данияр", "Ахметов", 20, g1.Title), g1),
            (new Student("Мария", "Иванова", 19, g1.Title), g1),
            (new Student("Тимур", "Касымов", 17, g2.Title), g2),
            (new Student("Аружан", "Бекова", 18, g2.Title), g2),
        };
        foreach (var (s, g) in students) { g.AddStudent(s); db.Students.Add(s); }

        var t1 = new Teacher("Ержан", "Омаров", 42, "Программирование", 15);
        var t2 = new Teacher("Светлана", "Петрова", 38, "Базы данных", 11);
        var t3 = new Teacher("Нурлан", "Темиров", 51, "Веб-разработка", 24);
        db.Teachers.AddRange(t1, t2, t3);
        db.SaveChanges();

        var sub1 = new Subject("Программирование", 120); sub1.AssignTeacher(t1);
        var sub2 = new Subject("Базы данных", 96); sub2.AssignTeacher(t2);
        var sub3 = new Subject("Веб-разработка", 108); sub3.AssignTeacher(t3);
        db.Subjects.AddRange(sub1, sub2, sub3);
        db.SaveChanges();

        var book = new GradeBook();
        var today = DateOnly.FromDateTime(DateTime.Today);
        int[] marks = { 5, 4, 3, 5, 4, 4 };
        for (int i = 0; i < students.Count; i++)
        {
            db.Grades.Add(book.AddGrade(students[i].s.Id, sub1.Id, marks[i], today.AddDays(-2)));
            db.Grades.Add(book.AddGrade(students[i].s.Id, sub2.Id, marks[(i + 2) % 6], today.AddDays(-1)));
        }

        var att = new Services.AttendanceManager(Array.Empty<AttendanceRecord>());
        for (int i = 0; i < students.Count; i++)
            for (int d = 0; d < 3; d++)
                db.Attendance.Add(att.AddRecord(students[i].s.Id, today.AddDays(-d), (i + d) % 4 != 0));

        db.SaveChanges();
    }
}

using CollegeManagement.Models;
using Microsoft.EntityFrameworkCore;

namespace CollegeManagement.Data;

public class CollegeDbContext : DbContext
{
    public CollegeDbContext(DbContextOptions<CollegeDbContext> options) : base(options) { }

    public DbSet<Student> Students => Set<Student>();
    public DbSet<Teacher> Teachers => Set<Teacher>();
    public DbSet<Group> Groups => Set<Group>();
    public DbSet<Subject> Subjects => Set<Subject>();
    public DbSet<Grade> Grades => Set<Grade>();
    public DbSet<AttendanceRecord> Attendance => Set<AttendanceRecord>();
    public DbSet<UserAccount> Users => Set<UserAccount>();

    protected override void OnModelCreating(ModelBuilder b)
    {
        b.Entity<Group>(e =>
        {
            e.HasMany(g => g.Students).WithOne().HasForeignKey(s => s.GroupId).OnDelete(DeleteBehavior.SetNull);
            e.Navigation(g => g.Students).HasField("_students").UsePropertyAccessMode(PropertyAccessMode.Field);
        });

        b.Entity<UserAccount>(e =>
        {
            e.Property<string>("_login").HasColumnName("Login");
            e.Property<string>("_passwordHash").HasColumnName("PasswordHash");
            e.HasIndex("_login").IsUnique();
        });

        b.Entity<Subject>().HasOne(s => s.Teacher).WithMany().HasForeignKey(s => s.TeacherId).OnDelete(DeleteBehavior.SetNull);
    }
}
